python multitask_classifier.py 

# for loading a model, make sure that we change the random seed 